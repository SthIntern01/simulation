# 🛡️ SandBox Security - Phishing Simulation Platform

Professional phishing simulation and employee security awareness training platform.

## 🚀 Features

### Dashboard
- **Real-time Click Tracking** - Monitor phishing link clicks in real-time
- **Advanced Analytics** - Comprehensive statistics and insights
- **Link Generator** - Create custom tracking links with parameters
- **Export Functionality** - Export data as CSV, JSON, or PDF
- **Advanced Filtering** - Filter by department, campaign, date range
- **Beautiful UI** - Professional blue/white design theme

### Tracking Capabilities
- User identification (Employee ID)
- Department tracking
- Campaign tracking
- IP address logging
- Browser/OS detection
- Geolocation (Country/City)
- Device type detection
- Timestamp recording

### API Endpoints

#### Click Tracking
- `POST /log` - Log a click event
- `GET /api/clicks` - Get all clicks (supports filtering)
- `DELETE /api/clicks/:id` - Delete specific click

#### Statistics
- `GET /api/stats` - Get overall statistics
- `GET /api/stats/by-department` - Clicks by department
- `GET /api/stats/by-campaign` - Clicks by campaign
- `GET /api/stats/by-browser` - Browser distribution
- `GET /api/stats/by-os` - OS distribution
- `GET /api/stats/timeline` - Click timeline (last 30 days)

#### Campaign Management
- `GET /api/campaigns` - Get all campaigns
- `POST /api/campaigns` - Create campaign
- `PUT /api/campaigns/:id` - Update campaign
- `DELETE /api/campaigns/:id` - Delete campaign

#### Department Management
- `GET /api/departments` - Get all departments
- `POST /api/departments` - Create department

#### Employee Management
- `GET /api/employees` - Get all employees
- `POST /api/employees` - Add employee

#### Export
- `GET /api/export/csv` - Export as CSV
- `GET /api/export/json` - Export as JSON

## 📦 Installation

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Setup

1. **Install dependencies:**
```bash
npm install
```

2. **Start the server:**
```bash
npm start
```

3. **For development (auto-reload):**
```bash
npm run dev
```

The server will start on `http://localhost:3000`

## 🎯 Usage

### Creating Tracking Links

#### Format:
```
http://YOUR-IP:3000/track.html?id=EMPLOYEE_ID&dept=DEPARTMENT&camp=CAMPAIGN
```

#### Example:
```
http://192.168.1.100:3000/track.html?id=EMP01&dept=HR&camp=Q1-2025
```

#### With Custom Redirect:
```
http://192.168.1.100:3000/track.html?id=EMP01&dept=HR&camp=Q1-2025&redirect=https://company.com
```

### Using the Dashboard

1. **Access Dashboard:**
   - Navigate to `http://localhost:3000/dashboard.html`

2. **Generate Links:**
   - Click "Generate Link" button
   - Fill in: Server IP, Employee ID, Department, Campaign
   - Copy generated link

3. **View Analytics:**
   - Real-time statistics on dashboard
   - Filter by department or campaign
   - Search specific records

4. **Export Data:**
   - Click "Export" dropdown
   - Choose format (CSV, JSON, PDF)
   - Download report

## 📁 File Structure

```
sandbox-security-phishing/
├── server.js              # Main server file
├── package.json           # Dependencies
├── clicks.db              # SQLite database (auto-created)
├── public/
│   ├── dashboard.html     # Main dashboard
│   └── track.html         # Tracking page
└── README.md
```

## 🗄️ Database Schema

### Clicks Table
```sql
CREATE TABLE clicks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    dept TEXT NOT NULL,
    campaign TEXT NOT NULL,
    ip TEXT,
    user_agent TEXT,
    time TEXT,
    browser TEXT,
    os TEXT,
    device TEXT,
    country TEXT,
    city TEXT,
    clicked_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

### Campaigns Table
```sql
CREATE TABLE campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

### Departments Table
```sql
CREATE TABLE departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    total_employees INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

## 🔒 Security Considerations

1. **Production Deployment:**
   - Use HTTPS (SSL/TLS certificates)
   - Implement authentication
   - Rate limiting
   - Input validation
   - SQL injection protection (already using parameterized queries)

2. **Data Privacy:**
   - Comply with data protection regulations
   - Implement data retention policies
   - Secure database access
   - Regular backups

3. **Network Security:**
   - Firewall configuration
   - Restrict API access
   - Monitor for abuse

## 🎨 Customization

### Changing Colors
Edit the CSS variables in `dashboard.html`:
```css
:root {
    --primary-color: #2563eb;
    --secondary-color: #1d4ed8;
    --accent-color: #60a5fa;
}
```

### Changing Redirect URL
Modify the default in `track.html`:
```javascript
const redirectUrl = params.get("redirect") || "https://your-site.com";
```

### Port Configuration
Set environment variable or change in `server.js`:
```bash
PORT=8080 npm start
```

## 📊 Sample Campaigns

### Q1 Security Awareness
```
Campaign: Q1-2025
Departments: HR, IT, Finance, Sales
Target: All employees
```

### Executive Phishing Test
```
Campaign: Executive-Test
Departments: Management
Target: C-level executives
```

### New Hire Training
```
Campaign: NewHire-Onboarding
Departments: All
Target: Recently hired employees
```

## 🐛 Troubleshooting

### Database locked error
```bash
# Stop server and restart
killall node
npm start
```

### Port already in use
```bash
# Use different port
PORT=8080 npm start
```

### CORS issues
- Server includes CORS middleware
- Check browser console for errors

## 📝 API Examples

### Log a Click (JavaScript)
```javascript
fetch('http://localhost:3000/log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        user_id: 'EMP01',
        dept: 'HR',
        campaign: 'Q1-2025',
        ip: '192.168.1.100',
        user_agent: navigator.userAgent,
        time: new Date().toUTCString()
    })
});
```

### Get Statistics (cURL)
```bash
curl http://localhost:3000/api/stats
```

### Export as CSV
```bash
curl http://localhost:3000/api/export/csv > report.csv
```

## 🤝 Contributing

This is an internal SandBox Security tool. For feature requests or bug reports, contact the security team.

## 📄 License

Proprietary - SandBox Security © 2025

## ⚠️ Disclaimer

This tool is for authorized security awareness training only. Use for legitimate phishing simulation and employee education purposes within your organization. Unauthorized use may be illegal.

---

**SandBox Security** - Securing Your Digital Perimeter
